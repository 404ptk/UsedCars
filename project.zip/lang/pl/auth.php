<?php

declare(strict_types=1);

return [
    'failed'   => 'Błędny login lub hasło.',
    'password' => 'Hasło jest nieprawidłowe.',
    'throttle' => 'Za dużo nieudanych prób logowania. Proszę spróbować za :seconds sekund.',
];
