@include('shared.html')

@include('shared.head', ['pageTitle' => 'UsedCarsPL'])

<body>
    @include('shared.navbar')
    @include('shared.card')
</body>