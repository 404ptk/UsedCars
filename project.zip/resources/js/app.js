import './bootstrap';
import 'bootstrap';
import Echo from 'laravel-echo';
//require('bootstrap');
//require('./boostrap');
// import axios from 'axios';
// window.axios = axios;
// require('./bootstrap');
